package Group_15.Trello_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrelloProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrelloProjectApplication.class, args);
	}

}
