package Group_15.Trello_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrelloProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
